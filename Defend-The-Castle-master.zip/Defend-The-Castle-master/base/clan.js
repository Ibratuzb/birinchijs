module.exports = {
	1: {
		xp: 100 * 3,
		members: 3,
		money: 100
	},
	2: {
		xp: 1000 * 3,
		members: 3,
		money: 1000
	},
	3: {
		xp: 10000 * 4,
		members: 4,
		money: 5000
	},
	4: {
		xp: 25000 * 5,
		members: 5,
		money: 5500
	},
	5: {
		xp: 50000 * 5,
		members: 6,
		money: 7000
	},
	6: {
		xp: 150000 * 5,
		members: 7,
		money: 10000
	},
	7: {
		xp: 400000 * 6,
		members: 7,
		money: 15000
	}
}
