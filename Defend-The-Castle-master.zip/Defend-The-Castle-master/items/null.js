module.exports = {
	0: {
		icon: '🚧',
		name: 'Void',
		city: true,
		battle: false,
		desc: 'I don\'t know what that does...'
	}
}
