module.exports = {
	11: {
		icon: '💎',
		name: 'Diamond',
		desc: 'Diamond!',
		city: false,
		battle: false
	}
}
